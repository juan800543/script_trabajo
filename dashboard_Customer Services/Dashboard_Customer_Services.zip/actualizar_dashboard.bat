@echo off
title Dashboard Customer Services
cd /d "%~dp0"

rem Si se abre desde dentro del .zip, Windows saca solo este .bat a una carpeta temporal
if not exist "%~dp0archivos\generar_dashboard.cs" (
    echo.
    echo [ERROR] No se encontro la carpeta "archivos" junto a este archivo.
    echo Casi siempre pasa porque se abrio desde DENTRO del .zip y no desde la carpeta extraida.
    echo.
    echo Como darse cuenta: en la barra de direcciones de la ventana aparece ".zip"
    echo y arriba se ve el boton "Extraer todo".
    echo.
    echo Haz esto:
    echo   1. Cierra esta ventana y la ventana del .zip.
    echo   2. Clic derecho sobre el .zip, elige "Extraer todo..." y luego "Extraer".
    echo   3. Se abre la carpeta extraida: ahi haz doble clic en actualizar_dashboard.bat
    echo.
    echo Consejo: despues de extraer, borra el .zip. La carpeta y el .zip tienen el mismo
    echo nombre y es facil abrir el que no es.
    echo.
    pause
    exit /b 1
)

rem Compilador de C# que trae Windows (.NET Framework 4.x): no hay que instalar nada
set "CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
if not exist "%CSC%" set "CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe"
if not exist "%CSC%" (
    echo.
    echo [ERROR] Este equipo no tiene .NET Framework 4, que viene con Windows 10 y 11.
    pause
    exit /b 1
)

echo Preparando el lector de Excel...
"%CSC%" /nologo /optimize /target:exe /out:"%~dp0archivos\generar_dashboard.exe" /r:System.IO.Compression.dll "%~dp0archivos\generar_dashboard.cs" >"%TEMP%\dashboard_csc.log" 2>&1
if errorlevel 1 (
    type "%TEMP%\dashboard_csc.log"
    echo.
    echo No se pudo preparar el lector de Excel. Revisa el mensaje de arriba.
    pause
    exit /b 1
)

echo Generando dashboard...
"%~dp0archivos\generar_dashboard.exe" %*
if errorlevel 1 (
    echo.
    echo No se pudo generar el dashboard. Revisa el mensaje de arriba.
    pause
    exit /b 1
)

start "" "%~dp0archivos\dashboard.html"
