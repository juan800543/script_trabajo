/*
Genera dashboard.html a partir del Excel de Customer Services.

Lo compila y ejecuta actualizar_dashboard.bat con el compilador de C# que trae Windows
(.NET Framework 4.x, incluido en Windows 10 y 11): no hay que instalar Python, Excel ni nada mas.

Uso:  actualizar_dashboard.bat             (usa el ultimo .xlsx cargado en la carpeta "entrada")
      actualizar_dashboard.bat ruta.xlsx   (usa otro archivo)

El HTML resultante es autocontenido (datos, logo y graficos dentro) y funciona sin internet.
Un .xlsx es un ZIP con XML adentro; la hoja "Data Form" pesa ~45 MB de XML, por eso se lee en modo flujo.
*/
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Xml;

public class ErrorDashboard : Exception
{
    public ErrorDashboard(string mensaje) : base(mensaje) { }
}

public class ResultadoDashboard
{
    public string Json;
    public int Filas;
    public int SinFecha;
}

public static class GeneradorDashboard
{
    static readonly CultureInfo Inv = CultureInfo.InvariantCulture;
    static readonly string[] Tipos = { "Nuevo", "Pass", "Reprocesamiento", "Existente", "Referencia" };

    // Errores de escritura evidentes. Solo se corrige el nombre: ninguna fila se elimina.
    static readonly Dictionary<string, string> CorreccionesLider = new Dictionary<string, string> {
        { "ADRIANA FLROES", "ADRIANA FLORES" }, { "ADRIANA FLOREZ", "ADRIANA FLORES" }, { "ADRIANA FLORE", "ADRIANA FLORES" },
        { "AADRIANA FLORES", "ADRIANA FLORES" }, { "ADRISNS FLORES", "ADRIANA FLORES" } };
    static readonly Dictionary<string, string> CorreccionesProveedor = new Dictionary<string, string> {
        { "DIRECTV CIMERCIAL", "DIRECTV COMMERCIAL" }, { "DIRECTV COMERCIAL", "DIRECTV COMMERCIAL" } };

    // Columna del dashboard -> nombres aceptados en el Excel (en mayusculas, sin espacios extra)
    static readonly string[][] Columnas = {
        new[] { "FECHA" }, new[] { "LEAD REP" }, new[] { "REP" }, new[] { "PROVEEDOR" }, new[] { "TIPO" },
        new[] { "REP CS" }, new[] { "DURACION" }, new[] { "VEL RESPUESTA", "V/ RESPUESTA" }, new[] { "CALIFICA" } };
    const int FECHA = 0, LIDER = 1, REP = 2, PROV = 3, TIPO = 4, CS = 5, DUR = 6, VEL = 7, CALIFICA = 8;

    const string NsRel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";

    public static ResultadoDashboard Generar(string ruta, string hoja)
    {
        List<object[]> filas;
        bool fecha1904;
        // FileShare.ReadWrite: se puede leer aunque el Excel este abierto
        using (var fs = new FileStream(ruta, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
        using (var zip = new ZipArchive(fs, ZipArchiveMode.Read))
        {
            string idHoja = BuscarHoja(zip, hoja, out fecha1904);
            string rutaHoja = BuscarDestino(zip, idHoja);
            List<string> compartidos = LeerCompartidos(zip);
            filas = LeerHoja(zip, rutaHoja, compartidos, hoja);
        }
        return Preparar(filas, fecha1904);
    }

    static XmlDocument CargarXml(ZipArchive zip, string nombre)
    {
        ZipArchiveEntry e = zip.GetEntry(nombre);
        if (e == null) return null;
        var doc = new XmlDocument();
        using (Stream s = e.Open()) doc.Load(s);
        return doc;
    }

    static string BuscarHoja(ZipArchive zip, string hoja, out bool fecha1904)
    {
        fecha1904 = false;
        XmlDocument doc = CargarXml(zip, "xl/workbook.xml");
        if (doc == null) throw new ErrorDashboard("El archivo no es un Excel valido (.xlsx).");
        foreach (XmlElement el in doc.GetElementsByTagName("*"))
        {
            if (el.LocalName == "workbookPr")
            {
                string d = el.GetAttribute("date1904");
                fecha1904 = d == "1" || d.ToLowerInvariant() == "true";
            }
        }
        foreach (XmlElement el in doc.GetElementsByTagName("*"))
            if (el.LocalName == "sheet" && string.Equals(el.GetAttribute("name").Trim(), hoja, StringComparison.OrdinalIgnoreCase))
                return el.GetAttribute("id", NsRel);
        throw new ErrorDashboard("El Excel no tiene la hoja '" + hoja + "'.");
    }

    static string BuscarDestino(ZipArchive zip, string id)
    {
        XmlDocument doc = CargarXml(zip, "xl/_rels/workbook.xml.rels");
        if (doc != null)
            foreach (XmlElement el in doc.GetElementsByTagName("*"))
                if (el.LocalName == "Relationship" && el.GetAttribute("Id") == id)
                {
                    string destino = el.GetAttribute("Target").Replace('\\', '/');
                    return destino.StartsWith("/") ? destino.Substring(1) : "xl/" + destino;
                }
        throw new ErrorDashboard("No se encontro la hoja dentro del archivo Excel.");
    }

    static List<string> LeerCompartidos(ZipArchive zip)
    {
        var lista = new List<string>();
        XmlDocument doc = CargarXml(zip, "xl/sharedStrings.xml");
        if (doc == null) return lista;
        foreach (XmlElement si in doc.DocumentElement.ChildNodes.OfType<XmlElement>().Where(x => x.LocalName == "si"))
        {
            var sb = new StringBuilder();
            AgregarTexto(si, sb);
            lista.Add(sb.ToString());
        }
        return lista;
    }

    // Une los <t> de un texto (incluido texto con formato), sin la guia fonetica <rPh>
    static void AgregarTexto(XmlNode nodo, StringBuilder sb)
    {
        foreach (XmlNode hijo in nodo.ChildNodes)
        {
            if (hijo.LocalName == "rPh") continue;
            if (hijo.LocalName == "t") sb.Append(hijo.InnerText);
            else if (hijo.NodeType == XmlNodeType.Element) AgregarTexto(hijo, sb);
        }
    }

    static int IndiceColumna(string referencia)
    {
        int n = 0;
        foreach (char ch in referencia)
        {
            if (ch < 'A' || ch > 'Z') break;
            n = n * 26 + (ch - 'A' + 1);
        }
        return n - 1;
    }

    static object ValorCelda(string tipo, string texto, List<string> compartidos)
    {
        object v;
        switch (tipo)
        {
            case "s": v = compartidos[int.Parse(texto, Inv)]; break;
            case "inlineStr": case "str": case "e": v = texto; break;
            case "b": v = texto == "1" ? "TRUE" : "FALSE"; break;
            default:
                double d;
                if (double.TryParse(texto, NumberStyles.Float, Inv, out d)) v = d; else v = texto;
                break;
        }
        // Igual que antes: una celda con texto vacio cuenta como vacia
        string s = v as string;
        return s != null && s.Length == 0 ? null : v;
    }

    static string Normalizar(string s)
    {
        return string.Join(" ", s.Split((char[])null, StringSplitOptions.RemoveEmptyEntries)).ToUpperInvariant();
    }

    static List<object[]> LeerHoja(ZipArchive zip, string rutaHoja, List<string> compartidos, string hoja)
    {
        ZipArchiveEntry entrada = zip.GetEntry(rutaHoja);
        if (entrada == null) throw new ErrorDashboard("No se encontro la hoja dentro del archivo Excel.");

        int[] indices = null;                       // columna del Excel de cada columna del dashboard
        var datos = new Dictionary<int, object[]>();  // numero de fila -> valores de las columnas usadas
        int primeraFila = -1, ultimaConDatos = -1, fila = 0, col = -1;
        var celdas = new Dictionary<int, object>();
        var texto = new StringBuilder();
        string tipo = null;
        bool enCelda = false, enValor = false, tieneValor = false;

        using (Stream s = entrada.Open())
        using (XmlReader r = XmlReader.Create(s))
        {
            while (r.Read())
            {
                switch (r.NodeType)
                {
                    case XmlNodeType.Element:
                        switch (r.LocalName)
                        {
                            case "row":
                                string rr = r.GetAttribute("r");
                                fila = rr != null ? int.Parse(rr, Inv) : fila + 1;
                                celdas.Clear(); col = -1;
                                if (r.IsEmptyElement) goto finFila;
                                break;
                            case "c":
                                string refc = r.GetAttribute("r");
                                col = refc != null ? IndiceColumna(refc) : col + 1;
                                tipo = r.GetAttribute("t");
                                texto.Length = 0; tieneValor = false;
                                enCelda = !r.IsEmptyElement;
                                break;
                            case "v": case "t":
                                if (enCelda) { tieneValor = true; enValor = !r.IsEmptyElement; }
                                break;
                        }
                        break;
                    case XmlNodeType.Text: case XmlNodeType.CDATA:
                    case XmlNodeType.Whitespace: case XmlNodeType.SignificantWhitespace:
                        if (enValor) texto.Append(r.Value);
                        break;
                    case XmlNodeType.EndElement:
                        if (r.LocalName == "v" || r.LocalName == "t") enValor = false;
                        else if (r.LocalName == "c")
                        {
                            enCelda = false;
                            if (tieneValor)
                            {
                                object v = ValorCelda(tipo, texto.ToString(), compartidos);
                                if (v != null) celdas[col] = v;
                            }
                        }
                        else if (r.LocalName == "row") goto finFila;
                        break;
                }
                continue;

            finFila:
                if (celdas.Count == 0) continue;
                if (indices == null)
                {
                    // La primera fila con datos son los titulos de las columnas
                    primeraFila = fila;
                    var titulos = new Dictionary<string, int>();
                    foreach (var kv in celdas.OrderBy(k => k.Key))
                    {
                        string t = Normalizar(Convert.ToString(kv.Value, Inv));
                        if (!titulos.ContainsKey(t)) titulos[t] = kv.Key;
                    }
                    indices = new int[Columnas.Length];
                    for (int i = 0; i < Columnas.Length; i++)
                    {
                        string encontrada = Columnas[i].FirstOrDefault(n => titulos.ContainsKey(n));
                        if (encontrada == null) throw new ErrorDashboard("Falta la columna '" + Columnas[i][0] + "' en la hoja '" + hoja + "'.");
                        indices[i] = titulos[encontrada];
                    }
                    continue;
                }
                var valores = new object[Columnas.Length];
                for (int i = 0; i < indices.Length; i++)
                {
                    object v;
                    if (celdas.TryGetValue(indices[i], out v)) valores[i] = v;
                }
                datos[fila] = valores;
                ultimaConDatos = fila;
            }
        }
        if (indices == null) throw new ErrorDashboard("La hoja '" + hoja + "' esta vacia.");

        // Las filas vacias intermedias se conservan (como orden sin datos); las del final se ignoran
        var filas = new List<object[]>();
        for (int f = primeraFila + 1; f <= ultimaConDatos; f++)
        {
            object[] v;
            filas.Add(datos.TryGetValue(f, out v) ? v : new object[Columnas.Length]);
        }
        return filas;
    }

    static string ComoTexto(object v)
    {
        if (v == null) return null;
        if (v is double)
        {
            double d = (double)v;
            return d == Math.Floor(d) && Math.Abs(d) < 1e15 ? ((long)d).ToString(Inv) : d.ToString("R", Inv);
        }
        return (string)v;
    }

    static string Texto(object v, string vacio)
    {
        string s = ComoTexto(v);
        if (s == null) return vacio;
        s = Normalizar(s);
        return s.Length == 0 ? vacio : s;
    }

    static int Segundos(object v)
    {
        double d;
        if (v is double) d = (double)v;
        else if (v == null || !double.TryParse((string)v, NumberStyles.Float, Inv, out d)) return -1;
        return (int)Math.Round(d, MidpointRounding.ToEven);
    }

    static int Dia(object v, bool fecha1904)
    {
        if (v is double)
        {
            // Numero de serie de Excel -> dias desde el 01/01/1970 (sin la hora)
            double serie = (double)v + (fecha1904 ? 1462 : 0);
            return (int)Math.Floor(serie) - 25569;
        }
        DateTime f;
        if (v is string && DateTime.TryParse((string)v, Inv, DateTimeStyles.None, out f))
            return (int)(f.Date - new DateTime(1970, 1, 1)).TotalDays;
        return int.MinValue;
    }

    static string Capitalizar(string s)
    {
        s = s.Trim();
        return s.Length == 0 ? s : s.Substring(0, 1).ToUpperInvariant() + s.Substring(1).ToLowerInvariant();
    }

    static ResultadoDashboard Preparar(List<object[]> filas, bool fecha1904)
    {
        int n = filas.Count;
        var dias = new int[n];
        var lider = new string[n]; var rep = new string[n]; var cs = new string[n];
        var prov = new string[n]; var tipo = new string[n];
        var q = new int[n]; var du = new int[n]; var vr = new int[n];
        int sinFecha = 0, primero = int.MaxValue, ultimo = int.MinValue;

        for (int i = 0; i < n; i++)
        {
            object[] f = filas[i];
            dias[i] = Dia(f[FECHA], fecha1904);
            if (dias[i] == int.MinValue) sinFecha++;
            else { primero = Math.Min(primero, dias[i]); ultimo = Math.Max(ultimo, dias[i]); }

            string l = Texto(f[LIDER], "SIN LIDER"), corregido;
            lider[i] = CorreccionesLider.TryGetValue(l, out corregido) ? corregido : l;
            rep[i] = Texto(f[REP], "SIN VENDEDOR");
            cs[i] = Texto(f[CS], "SIN ASIGNAR");
            string p = Texto(f[PROV], "SIN PROVEEDOR");
            prov[i] = CorreccionesProveedor.TryGetValue(p, out corregido) ? corregido : p;
            string t = ComoTexto(f[TIPO]);
            t = t == null ? null : Capitalizar(t);
            tipo[i] = t != null && Tipos.Contains(t) ? t : "Otro";
            // 0 = SI, 1 = NO, 2 = N/A, -1 = vacia
            string c = Texto(f[CALIFICA], "");
            q[i] = c == "SI" ? 0 : c == "NO" ? 1 : c == "N/A" ? 2 : -1;
            du[i] = Segundos(f[DUR]);
            vr[i] = Segundos(f[VEL]);
        }

        // Diccionarios ordenados por frecuencia (el indice 0 es el valor mas comun)
        Func<string[], List<string>> porFrecuencia = valores => valores
            .GroupBy(v => v).Select((g, orden) => new { g.Key, Cant = g.Count(), orden })
            .OrderByDescending(x => x.Cant).ThenBy(x => x.orden).Select(x => x.Key).ToList();
        List<string> dicLider = porFrecuencia(lider);
        // Los colores de la torta van a los lideres mas activos de los ultimos 90 dias
        var recientes = new Dictionary<string, int>();
        for (int i = 0; i < n; i++)
            if (dias[i] != int.MinValue && dias[i] >= ultimo - 89)
            {
                int c; recientes.TryGetValue(lider[i], out c); recientes[lider[i]] = c + 1;
            }
        dicLider = dicLider.Select((v, orden) => new { v, orden })
            .OrderByDescending(x => recientes.ContainsKey(x.v) ? recientes[x.v] : 0).ThenBy(x => x.orden).Select(x => x.v).ToList();
        List<string> dicTipo = Tipos.Concat(new[] { "Otro" }).Where(t => tipo.Contains(t)).ToList();

        var json = new StringBuilder();
        json.Append("{\"meta\":{\"generado\":").Append(Cadena(DateTime.Now.ToString("yyyy-MM-dd HH:mm", Inv)))
            .Append(",\"filas\":").Append(n).Append(",\"sinFecha\":").Append(sinFecha)
            .Append(",\"primerDia\":").Append(n > sinFecha ? primero.ToString(Inv) : "null")
            .Append(",\"ultimoDia\":").Append(n > sinFecha ? ultimo.ToString(Inv) : "null").Append("},\"dic\":{");
        var dics = new[] {
            new { nombre = "lider", lista = dicLider, valores = lider },
            new { nombre = "rep", lista = porFrecuencia(rep), valores = rep },
            new { nombre = "cs", lista = porFrecuencia(cs), valores = cs },
            new { nombre = "prov", lista = porFrecuencia(prov), valores = prov },
            new { nombre = "tipo", lista = dicTipo, valores = tipo } };
        json.Append(string.Join(",", dics.Select(d => Cadena(d.nombre) + ":[" + string.Join(",", d.lista.Select(Cadena)) + "]"))).Append("}");
        json.Append(",\"d\":").Append(Arreglo(dias.Select(d => d == int.MinValue ? -1 : d)));
        string[] claves = { "l", "r", "c", "p", "t" };
        for (int k = 0; k < dics.Length; k++)
        {
            var posicion = new Dictionary<string, int>();
            for (int i = 0; i < dics[k].lista.Count; i++) posicion[dics[k].lista[i]] = i;
            json.Append(",\"").Append(claves[k]).Append("\":").Append(Arreglo(dics[k].valores.Select(v => posicion[v])));
        }
        json.Append(",\"q\":").Append(Arreglo(q)).Append(",\"du\":").Append(Arreglo(du)).Append(",\"vr\":").Append(Arreglo(vr)).Append("}");
        return new ResultadoDashboard { Json = json.ToString(), Filas = n, SinFecha = sinFecha };
    }

    static string Arreglo(IEnumerable<int> valores)
    {
        return "[" + string.Join(",", valores.Select(v => v.ToString(Inv))) + "]";
    }

    // Texto JSON; "</" se escapa para que ningun texto del Excel pueda cerrar el <script>
    public static string Cadena(string s)
    {
        var sb = new StringBuilder("\"");
        foreach (char ch in s)
        {
            switch (ch)
            {
                case '"': sb.Append("\\\""); break;
                case '\\': sb.Append("\\\\"); break;
                case '\n': sb.Append("\\n"); break;
                case '\r': sb.Append("\\r"); break;
                case '\t': sb.Append("\\t"); break;
                case '/': sb.Append(sb.Length > 0 && sb[sb.Length - 1] == '<' ? "\\/" : "/"); break;
                default:
                    if (ch < 0x20 || ch == '\u2028' || ch == '\u2029') sb.Append("\\u").Append(((int)ch).ToString("x4"));
                    else sb.Append(ch);
                    break;
            }
        }
        return sb.Append('"').ToString();
    }
}

public static class Programa
{
    const string Hoja = "Data Form";

    static int Main(string[] args)
    {
        try
        {
            Ejecutar(args);
            return 0;
        }
        catch (ErrorDashboard e) { return Fallar(e.Message); }
        catch (IOException e) { return Fallar("No se pudo leer o escribir un archivo: " + e.Message); }
        catch (Exception e) { return Fallar("El archivo no se pudo leer como Excel (.xlsx): " + e.Message); }
    }

    static int Fallar(string mensaje)
    {
        Console.WriteLine();
        Console.WriteLine("[ERROR] " + mensaje);
        Console.WriteLine();
        return 1;
    }

    // Fecha en que el archivo llego a la carpeta: al copiar, Windows conserva la fecha de
    // modificacion original, pero la de creacion es la de la copia. Se usa la mas reciente.
    static DateTime FechaCarga(FileInfo f)
    {
        return f.CreationTime > f.LastWriteTime ? f.CreationTime : f.LastWriteTime;
    }

    static void Ejecutar(string[] args)
    {
        string carpeta = AppDomain.CurrentDomain.BaseDirectory;
        // "entrada" va junto al programa o una carpeta arriba (en el paquete, junto al .bat y fuera de "archivos")
        string entrada = Path.Combine(carpeta, "entrada");
        DirectoryInfo padre = Directory.GetParent(carpeta.TrimEnd(Path.DirectorySeparatorChar));
        if (!Directory.Exists(entrada) && padre != null && Directory.Exists(Path.Combine(padre.FullName, "entrada")))
            entrada = Path.Combine(padre.FullName, "entrada");
        string plantilla = Path.Combine(carpeta, "plantilla_dashboard.html");
        // El logo puede estar en "Imagenes_referencia" o suelto junto al programa
        string logo = Path.Combine(carpeta, "Imagenes_referencia", "ICON-ALLIANCE.png");
        if (!File.Exists(logo)) logo = Path.Combine(carpeta, "ICON-ALLIANCE.png");
        string salida = Path.Combine(carpeta, "dashboard.html");

        // El Excel a usar: el indicado, o el ultimo cargado en "entrada" (sin importar su nombre)
        FileInfo archivo;
        if (args.Length > 0)
        {
            archivo = new FileInfo(args[0]);
            if (!archivo.Exists) throw new ErrorDashboard("No se encontro el Excel:\n  " + archivo.FullName);
        }
        else
        {
            if (!Directory.Exists(entrada)) throw new ErrorDashboard("No existe la carpeta:\n  " + entrada);
            List<FileInfo> archivos = new DirectoryInfo(entrada).GetFiles("*.xlsx")
                .Where(f => f.Extension.Equals(".xlsx", StringComparison.OrdinalIgnoreCase) && !f.Name.StartsWith("~$"))
                .OrderByDescending(FechaCarga).ToList();
            if (archivos.Count == 0)
                throw new ErrorDashboard("No hay ningun archivo .xlsx en la carpeta:\n  " + entrada + "\nCopia ahi el Excel y vuelve a intentar.");
            if (archivos.Count > 1)
                Console.WriteLine("Hay " + archivos.Count + " archivos .xlsx en 'entrada'; se usa el ultimo cargado.");
            archivo = archivos[0];
        }
        if (!File.Exists(plantilla)) throw new ErrorDashboard("No se encontro la plantilla:\n  " + plantilla);

        Console.WriteLine("Leyendo " + archivo.Name + " (hoja '" + Hoja + "')...");
        var reloj = System.Diagnostics.Stopwatch.StartNew();
        ResultadoDashboard r = GeneradorDashboard.Generar(archivo.FullName, Hoja);

        string json = r.Json.Replace("\"meta\":{", "\"meta\":{\"fuente\":" + GeneradorDashboard.Cadena(archivo.Name) + ",");
        string logoB64 = File.Exists(logo) ? Convert.ToBase64String(File.ReadAllBytes(logo)) : "";
        var utf8 = new UTF8Encoding(false);
        string html = File.ReadAllText(plantilla, utf8).Replace("__LOGO_B64__", logoB64).Replace("__DATA_JSON__", json);
        File.WriteAllText(salida, html, utf8);

        Console.WriteLine(string.Format(Inv, "OK: {0:N0} ordenes procesadas ({1} sin fecha valida) en {2:N1} s.", r.Filas, r.SinFecha, reloj.Elapsed.TotalSeconds));
        Console.WriteLine("Dashboard generado: " + salida);
    }

    static readonly CultureInfo Inv = CultureInfo.InvariantCulture;
}
