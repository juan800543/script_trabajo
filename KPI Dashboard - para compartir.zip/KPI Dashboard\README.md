﻿# Dashboard KPI Sales Department

Genera `dashboard.html` a partir del Excel mensual de KPIs. El HTML resultante es autocontenido:
se abre con doble clic, sin internet y sin Python instalado.

**El Excel de entrada nunca se modifica.** El script solo lo lee.

---

## 1. Puesta en marcha (una sola vez por PC)

**Requisito: tener Python instalado.** Si no lo está, descárgalo de
<https://www.python.org/downloads/> y, durante la instalación, **marca la casilla
«Add Python to PATH»** — si no la marcas, el archivo `.bat` no lo encontrará.

No hay que instalar las librerías a mano: la primera vez que ejecutes `Generar_dashboard.bat`
lo hace solo. Si prefieres hacerlo tú:

```
pip install pandas openpyxl plotly
```

## 2. Uso

1. Copia el Excel del mes en la carpeta **`Entrada`**.
2. Doble clic en **`Generar_dashboard.bat`**.
3. Se genera `dashboard.html` junto al `.bat` y se abre solo en el navegador.

Tarda 1 o 2 segundos. Puedes ejecutarlo tantas veces al día como quieras: siempre sobrescribe el
mismo archivo, así que un enlace compartido no deja de funcionar nunca.

> También puedes abrir `dashboard_kpi.py` en VS Code y pulsar ▶ Run. Hace exactamente lo mismo.

### La carpeta se puede mover

Todas las rutas cuelgan de donde esté guardado `dashboard_kpi.py`. Puedes copiar la carpeta al
Escritorio, a `D:\`, a una carpeta de red o donde quieras, y funciona sin tocar nada. Lo único
que importa es que `Entrada` siga estando **al lado** del `.py`.

### Qué archivo toma

El `.xlsx` con la **fecha de modificación más reciente** de `Entrada`. Los archivos temporales de
Excel (`~$...`) se ignoran, así que puedes tener el Excel abierto mientras lo ejecutas.

> **Ojo a principios de mes:** si nadie ha pegado los datos nuevos todavía, el script tomará el
> archivo del mes pasado sin quejarse — los datos son válidos, solo que viejos. Por eso la
> cabecera del dashboard muestra siempre el **nombre del archivo usado, la fecha de corte y la
> hora de generación**. Revísalos antes de compartir el enlace.

## 3. Compartir el resultado

Para que alguien **solo vea** el tablero, mándale únicamente `dashboard.html`. Lleva todo dentro
(gráficos incluidos): no necesita Python, ni librerías, ni internet.

Para que alguien **genere el suyo**, pásale la carpeta completa: `dashboard_kpi.py`,
`Generar_dashboard.bat`, este `README.md` y una carpeta `Entrada` vacía. El Excel no hace falta
mandarlo: cada uno pone el suyo.

## 4. Cambiar la carpeta de salida (por ejemplo, publicar en red)

Por defecto el HTML se genera junto al script. Para publicarlo en otro sitio, edita esta línea
del bloque `CONFIG`, arriba del todo en `dashboard_kpi.py`:

```python
CARPETA_SALIDA = CARPETA_BASE                 # por defecto: junto al script
CARPETA_SALIDA = r"\\servidor\carpeta\kpi"    # publicar en red
```

Guardas y ya está: **no hay nada que recompilar**. El `.bat` no contiene el código, solo llama al
`.py`, así que no se toca nunca. La carpeta destino se crea sola si no existe. El prefijo `r"..."`
es obligatorio: evita que las barras invertidas se interpreten mal.

No hay rutas escritas a mano en ninguna otra parte del código.

> **Si ya repartiste la carpeta a tus compañeros**, cada uno tiene **su propia copia** del `.py`.
> Editar el tuyo no cambia el de ellos: hay que volver a pasarles el archivo. Ver el punto 5.

Otra constante útil en el mismo bloque:

```python
ABRIR_AL_TERMINAR = True    # False si no quieres que se abra el navegador cada vez
```

## 5. Cómo repartir un cambio del script

Cada compañero tiene su copia de `dashboard_kpi.py`. Si editas el tuyo (una ruta, una campaña
nueva en `MAPEO_COLAS`), hay dos formas de que les llegue:

**Opción A — mandar el archivo.** Les pasas el `dashboard_kpi.py` nuevo y lo pegan encima del
suyo, sobrescribiendo. Es lo más simple si sois pocos. Nada más cambia: ni el `.bat`, ni la
carpeta `Entrada`, ni el Excel.

**Opción B — una sola copia en red.** Dejas la carpeta del script en una unidad compartida y
todos ejecutan el `.bat` desde ahí. Así solo existe un `.py` y cualquier cambio les llega solo,
sin repartir nada.

> Si eliges la opción B, **deja `CARPETA_SALIDA` como está** (junto al script). Si además la
> apuntas a una carpeta fija de red, todos escribirían en el mismo `dashboard.html` y el último
> que ejecute pisaría el de los demás. Publicar en red tiene sentido cuando **una sola persona**
> genera el tablero para todos, no cuando lo genera cada uno.

## 6. Si aparece una campaña nueva

Los nombres de campaña de la hoja `Print` **no coinciden** con los nombres de cola del reporte de
llamadas. La traducción vive en el diccionario `MAPEO_COLAS`, dentro de `CONFIG`:

```python
MAPEO_COLAS = {
    "NEXTL2": ["NEXOTL 2", "NEXOTL 1"],        # una campaña puede sumar varias colas
    "Heri Mob 1": ["Heri Mob 1", "HERIMOBILE"], # el nombre cambió de un mes a otro
    "TMETRO": [],                               # lista vacía = no tiene llamadas
    ...
}
```

Para añadir una campaña:

1. Mira cómo se llama en la columna **Campaña** de la hoja `Print`.
2. Mira cómo se llama en la columna **Queue Name** de `RawDataRingCentral`.
3. Añade la línea `"nombre en Print": ["nombre en el raw"],`.

Si la campaña todavía no tiene llamadas, deja la lista vacía: `[]`.

Tres cosas que evitan trabajo:

- **Las mayúsculas y los acentos dan igual.** `Flatexco` y `FLATEXCO` son la misma cola.
- **Se pueden poner varios nombres.** Si una cola se renombra, deja el viejo y añade el nuevo:
  así el script sigue funcionando con los archivos de meses anteriores.
- **Si una campaña recibe de varias colas**, ponlas todas y se suman.

**No hace falta que te acuerdes de esto.** Si aparece una campaña nueva en `Print` y no está en
`MAPEO_COLAS`, el script se detiene y te escribe la línea exacta que tienes que pegar:

```
Hay campañas en la hoja 'Print' que no están en MAPEO_COLAS: 'Fibra Norte'.
    Abre dashboard_kpi.py, busca MAPEO_COLAS y añade una línea por cada una:
        "Fibra Norte": ["nombre de su cola en RawDataRingCentral"],  # o [] si no tiene llamadas
```

Nunca genera un dashboard al que le falten llamadas sin avisar.

## 7. Qué hace el script si algo va mal

No genera el HTML. Aborta e imprime en la terminal qué pasó y en qué hoja. Casos cubiertos:

| Situación | Qué verás |
|---|---|
| No hay `.xlsx` en `Entrada` | `No hay ningun archivo .xlsx en la carpeta: ...` |
| Falta la hoja `Print` | `El Excel no tiene la hoja 'Print'...` |
| Falta una cabecera esperada | `No se encontro la cabecera de Tabla 1 (Llamadas)...` |
| Hay un `#REF!` o `#VALUE!` en una celda necesaria | `Celda con error '#REF!' en Print (...)` |
| Una campaña nueva sin mapear | `Hay campañas en la hoja 'Print' que no están en MAPEO_COLAS...` |
| Las llamadas no cuadran | `La suma de llamadas día a día (...) no coincide con el total de 'Print'` |

La ventana se queda abierta para que puedas leer el mensaje. **El dashboard anterior no se toca**:
si algo falla, el que ya tenías sigue siendo válido.

La filosofía es deliberada: **un dashboard con números equivocados y buena pinta es peor que uno
que no se genera.**

## 8. Validación automática

Antes de dibujar nada, el script se autocomprueba. Hay dos niveles:

**Siempre, sea el mes que sea:**

- Que toda campaña de `Print` esté en `MAPEO_COLAS`.
- Que la suma de llamadas día a día cuadre exactamente con el total del corte.
- Que no haya `#REF!` ni `#VALUE!` en ninguna celda que se necesite.
- Que estén todas las cabeceras esperadas.

Estas son las que protegen a los meses futuros: sin ellas, una campaña nueva perdería sus
llamadas en silencio y el dashboard parecería correcto.

**Solo para los cortes ya revisados a mano:** además compara 12 cifras exactas (llamadas,
perdidas, % perdidas, ventas cliente y línea, monto, las dos eficiencias, llamadas/día, leads de
META HERI, total general y la suma de la serie diaria). Están en `CIFRAS_DE_CONTROL_POR_CORTE`,
dentro de `CONFIG`.

La clave de esa tabla es **(mes, fecha de corte)**, no solo el mes. Es importante: el mismo Excel
se actualiza cada día con un corte nuevo, así que unas cifras atadas solo al mes fallarían en
cuanto avanzara el corte, aunque los datos estuvieran perfectos.

**Rellenarla es opcional.** Un corte que no esté en la tabla se salta estas comprobaciones y se
queda con las universales, que son las que de verdad protegen. No hay que añadir nada cada día.

## 9. Hojas que el script usa y que ignora

**Usa:** `Print` (métricas del corte), `RawDataRingCentral` (llamadas por día),
`Raw Data General` (ventas por día), `Valores$$$` (costo capturado).

**Usa solo si hace falta:** las hojas de llamadas auxiliares. **El nombre cambia según el mes**
(`RawDataRingCentral HM2` en mayo, `RawDataRingCentral HM2-IA` desde junio), así que no se buscan
por nombre exacto sino por prefijo: cualquier hoja que empiece por `RawDataRingCentral`. El nombre
viene de las campañas que contiene — **H**eri **M**ob **2**, y desde junio también **IA** FCO
Internet.

Son hojas tramposas porque cambian de papel según el mes:

- **Agosto 2026:** esas campañas estaban en la hoja principal y la auxiliar traía otro conjunto de
  datos que `Print` no incluye. Sumarla habría inflado las cifras cerca del 50 %.
- **Julio y junio 2026:** la hoja principal no trae `Heri Mob 2` ni `IA FCO Internet`, y la
  auxiliar es su única fuente. Sin ella faltaban 3.681 llamadas en julio.
- **Mayo 2026:** igual, pero solo con `Heri Mob 2` (1.577 llamadas) y con la hoja llamada `HM2`.

Por eso no se pueden ni usar siempre ni ignorar siempre. La regla es: **la hoja principal manda, y
en las auxiliares solo se buscan las campañas que no aparecieron allí.** Cuando eso ocurre, el
dashboard lo avisa diciendo de qué hoja las sacó. La validación final (que la suma diaria cuadre
con `Print`) confirma que la elección fue la correcta.

**Ignora a propósito:**

- `Print (2)`, `Print (3)`, `Grupos (2)` — contienen `#REF!` y `#VALUE!`.
- `Grupos`, ranking por asesor, ciudad o proveedor — fuera de alcance.

## 10. Historial de cambios entre meses

Lo que cambió del archivo de agosto 2026 al de julio 2026, por si vuelve a pasar:

| Cambio | Cómo se resolvió |
|---|---|
| Campaña `ITSFIBERNET` sustituida por `R-FRONTIER` | Añadida a `MAPEO_COLAS` con lista vacía (0 llamadas) |
| Cola `Heri Mob 1` renombrada a `HERIMOBILE` | Las dos conviven como alias de la misma campaña |
| Cola `Flatexco` pasó a `FLATEXCO` | La comparación ignora mayúsculas, no hizo falta tocar nada |
| Apareció la cola `NEXOTL 1` junto a `NEXOTL 2` | `NEXTL2` ahora suma las dos |
| `Heri Mob 2` e `IA FCO Internet` salieron de la hoja principal | Se buscan en `RawDataRingCentral HM2-IA` |
| Se invirtió el orden de las columnas en `Raw Data General` | Ahora se leen por el nombre de la cabecera |
| Los costos pasaron de un único día a repartidos por día | El `Monto` ya solo se usa para desempatar, no para descartar |
| El corte de agosto avanzó del 11 al 12 (9 → 10 días hábiles) | Las cifras de control se indexan por (mes, corte), no solo por mes |
| `R-FRONTIER` (julio) volvió a ser `ITSFIBERNET` (agosto) | Las dos conviven en `MAPEO_COLAS`, sin llamadas |
| `ALLI WL2` y `ALLI WL4` ya traen ventas propias | Se vació `CAMPANAS_SIN_SERIE_DIARIA_CONOCIDAS` para no silenciar el aviso si vuelve a pasar |
| La hoja auxiliar se llamaba `RawDataRingCentral HM2` en mayo y `... HM2-IA` desde junio | Se detectan por prefijo, no por nombre exacto |

Ninguno de estos cambios se detectó a ojo: todos los destapó la validación al no cuadrar las
cifras. Por eso conviene no desactivarla nunca.

## 11. Rarezas conocidas de los datos

Estas no son fallas del script, son cosas del Excel de origen. El dashboard las muestra en el
recuadro **Notas de datos**, arriba del todo, para que nadie saque conclusiones equivocadas:

> **Ya corregidas en el archivo con corte 12/08.** Se dejan documentadas porque el script sigue
> detectándolas solo si vuelven a aparecer.
>
> - **ALLI WL2 y ALLI WL4 sin desglose día a día.** En el archivo con corte 11/08 sus ventas
>   (102/155 y 77/104) eran un calco exacto, día por día, de ALLI WL3 y Heri Mob 1, sin bloque
>   propio en `Raw Data General`. En el archivo corregido ya traen datos propios.
> - **ALLI WL2 con eficiencia superior al 100 %** (3 llamadas, 102 ventas): imposible en la
>   operación real, y consecuencia del punto anterior.
>
> Si algo así reaparece, el dashboard lo avisa en **Notas de datos** y esas campañas quedan fuera
> del gráfico de eficiencia diaria — tanto sus ventas como sus llamadas, para que numerador y
> denominador cubran las mismas campañas. En las tarjetas y en la tabla siguen completas, porque
> esas cifras vienen de `Print`.

### Ventas (Cliente) duplicando a Ventas (Línea) — mayo y junio 2026

**Pendiente de revisar con quien arma el Excel.** En esos dos meses, `ALLI WL3` y `ALLI WL4`
tienen en `Print` el mismo número en *Ventas (Cliente)* que en *Ventas (Línea)*, y no coincide con
el detalle de `Raw Data General`:

| Mes | Campaña | `Print` cliente/línea | Bloque de detalle |
|---|---|---|---|
| Mayo | ALLI WL3 | 454 / 454 | **341** / 454 |
| Mayo | ALLI WL4 | 146 / 146 | **114** / 146 |
| Junio | ALLI WL3 | 239 / 239 | **188** / 239 |
| Junio | ALLI WL4 | 293 / 293 | **209** / 293 |

Tiene toda la pinta de una fórmula copiada de la columna de al lado. La hoja `Print` es coherente
consigo misma (los totales suman bien), así que el error se propaga al total: en mayo la
eficiencia /Cliente sale 7,11 % cuando con las cifras del detalle sería 6,57 %.

El script **no lo corrige**, porque sería inventar datos. Muestra lo que dice `Print` y deja esas
campañas fuera de la serie diaria de ventas, avisándolo. En julio y agosto no ocurre.

> Ojo: que *cliente* y *línea* coincidan no es por sí solo un error — pasa cuando cada venta es de
> una sola línea (`FLATEXCO` en agosto, `NEXTL2` en julio, y ambas cuadran con su detalle). Lo
> sospechoso es que además **no cuadre** con el bloque de `Raw Data General`.
- **Los costos van con retraso.** `Valores$$$` se captura a mano; en agosto solo el día 1 tiene
  importes. Por eso el costo se presenta como dato del corte y no como serie diaria: los días en
  cero significan «aún no cargado», no «sin inversión».

El gráfico **Eficiencia por campaña** deja fuera a las campañas con eficiencia imposible y lo dice
bajo el título. Con ALLI WL2 dentro, su 3.400 % aplastaba la escala y las demás barras quedaban
pegadas al suelo, invisibles. La campaña sigue completa en la tabla de detalle y en las notas.

Si el mes que viene aparece un bloque propio para WL2 y WL4, el script los detectará solo y los
incluirá en el gráfico diario sin tocar código.

## 12. Cómo lee el script (por si hay que tocarlo)

- Las tablas se localizan **buscando las etiquetas de texto**, nunca por coordenadas fijas. Si el
  layout se mueve unas filas, sigue funcionando. Esto vale también para las columnas dentro de
  cada bloque de `Raw Data General`: en agosto 2026 venía primero `Count of WO Sale Date` y en
  julio 2026 primero `Sum of V-linea`. Leerlas por posición intercambiaba clientes con líneas sin
  que saltara ningún error.
- Los nombres de cola **cambian de un mes a otro** (`Heri Mob 1` → `HERIMOBILE`, `Flatexco` →
  `FLATEXCO`), y una campaña puede recibir llamadas de varias colas a la vez (`NEXTL2` =
  `NEXOTL 2` + `NEXOTL 1`). Por eso `MAPEO_COLAS` admite una lista de nombres por campaña y
  compara ignorando mayúsculas y acentos.
- El libro se abre en modo `read_only` y en una sola pasada. Es lo que hace que tarde ~1,5 s en
  vez de ~16 s: en modo normal, openpyxl carga también `RawDataRingCentral HM2-IA`, que declara
  más de un millón de filas aunque no se use.
- Los bloques de `Raw Data General` vienen duplicados. El script los deduplica y luego asigna cada
  bloque a su campaña por el `Grand Total`. Solo acepta correspondencias 1 a 1: si un bloque encaja
  con dos campañas (mismas ventas por casualidad, o por una referencia cruzada del Excel), recurre
  al `Monto` para desempatar; si aun así queda ambiguo, no adivina — deja esa campaña fuera de la
  serie diaria y lo reporta. El `Monto` **solo** desempata, nunca descarta: los costos a veces
  vienen en un único día y otras repartidos, y no siempre suman el total de `Print`.
- Las fechas del raw vienen mezcladas (unas como fecha, otras como texto `MM/DD/YYYY`). Se
  normalizan antes de agrupar.
- Los días posteriores al corte se dibujan como huecos (`None`), **nunca como cero**: un cero
  dibujaría una caída a plomo que no ocurrió.

## 13. El diseño (por si hay que tocarlo)

El tablero está maquetado a mano, sin frameworks ni CSS externo: se abre sin internet, así que
tampoco usa fuentes web (tira de la fuente del sistema, Segoe UI en Windows). Todo el diseño vive
en dos constantes de `dashboard_kpi.py`, justo encima de `construir_html`:

- **`CSS_DASHBOARD`** — la hoja de estilos completa. Los colores y medidas están arriba del todo,
  en el bloque `:root`; cambiar ahí un color lo cambia en todo el tablero.
- **`JS_DASHBOARD`** — las dos únicas piezas de interacción: el menú de arriba que se ilumina
  según la sección visible, y el reproductor del gráfico diario.

Debajo hay unos ayudantes pequeños que construyen los bloques visuales (`_bloque_columnas`,
`_barras_reparto`, `_area_escalonada`, `_matriz_puntos`) y `_estilo_plotly`, que deja los tres
gráficos de Plotly con la misma tipografía y los mismos colores que el resto.

**El botón «Reproducir» no usa la animación de Plotly.** `Plotly.animate` deja la serie sin línea
ni relleno al saltar de fotograma (solo quedan los puntos sueltos), así que la reproducción va por
`Plotly.restyle`, recortando la serie día a día desde el propio tablero. Si algún día se vuelve a
tocar ese gráfico, conviene no reintroducir `frames` ni el slider de Plotly.

Cada tarjeta tiene un botón redondo `···` que abre una nota corta explicando qué mide y de qué
hoja del Excel sale el dato. El texto de esas notas está en `construir_html`, en las variables
`ayuda_*`.

## 14. Archivos

```
Carpeta del dashboard (puede estar donde quieras)
├── Entrada\                  <- aquí va el Excel del mes
│   └── KPI Sales ....xlsx
├── Generar_dashboard.bat     <- doble clic para generar
├── dashboard_kpi.py          <- el script
├── dashboard.html            <- el resultado (se sobrescribe en cada ejecución)
└── README.md                 <- este archivo
```

Para pasarle la carpeta a un compañero, mándale todo **menos** `dashboard.html` y el Excel de
`Entrada`. Esos dos los genera y los pone él.
